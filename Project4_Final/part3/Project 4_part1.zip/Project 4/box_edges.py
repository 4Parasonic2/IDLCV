#!/usr/bin/env python3
"""
Edge Boxes proposal extraction for the Potholes dataset.

- Loops over all images in splits (train / val / test)
- Runs Edge Boxes (using StructuredEdgeDetection)
- Saves proposals as JSON: {filename: [[x1,y1,x2,y2], ...], ...}
"""

import os
import json
import cv2
import numpy as np

try:
    from tqdm import tqdm
except ImportError:
    tqdm = lambda x, **kwargs: x  # no-op if tqdm not installed


# ---------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------
DATA_ROOT = "/dtu/datasets1/02516/potholes"
IMAGES_DIR = os.path.join(DATA_ROOT, "images")

END_PATH = "/zhome/4d/5/147570/IDLCV/Project_4/results"
os.makedirs(END_PATH, exist_ok=True)

# If you already have splits.json (with train/val/test), it will be used.
# Otherwise, we create a simple 80/10/10 split and save it here:
SPLITS_PATH = os.path.join(END_PATH, "splits.json")

OUTPUT_DIR = os.path.join(END_PATH, "proposals_edgeboxes")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Path to the Structured Edge Detection model (VERY IMPORTANT)
# e.g. EDGE_MODEL_PATH = "/zhome/.../models/model.yml.gz"
EDGE_MODEL_PATH = "/zhome/4d/5/147570/IDLCV/Project_4/model.yml"

MAX_PROPOSALS = 2000  # max boxes per image (EdgeBoxes' setMaxBoxes)


# ---------------------------------------------------------------------
# Helper: create or load splits
# ---------------------------------------------------------------------
def ensure_splits():
    """
    Load splits.json if it exists, otherwise create a simple
    train/val/test split from IMAGES_DIR and save it.
    """
    if os.path.isfile(SPLITS_PATH):
        with open(SPLITS_PATH, "r") as f:
            splits = json.load(f)
        print(f"Loaded splits from {SPLITS_PATH}")
        return splits

    files = [
        f for f in os.listdir(IMAGES_DIR)
        if f.lower().endswith((".jpg", ".jpeg", ".png"))
    ]
    files = sorted(files)

    import random
    random.seed(42)
    random.shuffle(files)

    n = len(files)
    n_train = int(0.8 * n)
    n_val   = int(0.1 * n)
    n_test  = n - n_train - n_val

    train_files = files[:n_train]
    val_files   = files[n_train:n_train + n_val]
    test_files  = files[n_train + n_val:]

    splits = {
        "train": train_files,
        "val": val_files,
        "test": test_files,
    }

    with open(SPLITS_PATH, "w") as f:
        json.dump(splits, f, indent=2)

    print(f"Created splits.json at {SPLITS_PATH}")
    print(f"  train: {len(train_files)}, val: {len(val_files)}, test: {len(test_files)}")
    return splits


# ---------------------------------------------------------------------
# Edge Boxes helpers
# ---------------------------------------------------------------------
def create_edge_detector(model_path):
    """
    Create StructuredEdgeDetection object for EdgeBoxes.
    """
    if not hasattr(cv2, "ximgproc"):
        raise RuntimeError(
            "cv2.ximgproc not available. Install opencv-contrib-python, e.g.\n"
            "    pip install opencv-contrib-python"
        )
    if not os.path.isfile(model_path):
        raise FileNotFoundError(
            f"Structured edge model not found at {model_path}.\n"
            "Download model.yml.gz from OpenCV extra data and set EDGE_MODEL_PATH."
        )

    edge_detector = cv2.ximgproc.createStructuredEdgeDetection(model_path)
    return edge_detector


def create_edge_boxes(max_boxes=None):
    """
    Create EdgeBoxes object and configure basic parameters.
    """
    eb = cv2.ximgproc.createEdgeBoxes()

    # You can tweak these if you want:
    # eb.setAlpha(0.65)
    # eb.setBeta(0.75)
    # eb.setMinScore(0.01)
    # eb.setMaxBoxes(1000)

    if max_boxes is not None:
        eb.setMaxBoxes(int(max_boxes))

    return eb


def extract_edgeboxes_for_image(img_path, edge_detector, edge_boxes, max_proposals=None):
    """
    Run EdgeBoxes on a single image.

    Returns np.ndarray of shape (N, 4) with [x1, y1, x2, y2].
    """
    img_bgr = cv2.imread(img_path, cv2.IMREAD_COLOR)
    if img_bgr is None or img_bgr.size == 0:
        print(f"WARNING: Cannot read or empty image: {img_path}. Skipping.")
        return np.zeros((0, 4), dtype=np.int32)

    H, W = img_bgr.shape[:2]

    # EdgeBoxes expects RGB in [0,1] float
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    img_rgb = img_rgb.astype(np.float32) / 255.0

    try:
        edges = edge_detector.detectEdges(img_rgb)
        orientation = edge_detector.computeOrientation(edges)
        edges_nms = edge_detector.edgesNms(edges, orientation)
    except cv2.error as e:
        print(f"OpenCV error in edge detection for {img_path}:\n  {e}")
        return np.zeros((0, 4), dtype=np.int32)

    try:
        boxes, scores = edge_boxes.getBoundingBoxes(edges_nms, orientation)
    except cv2.error as e:
        print(f"OpenCV error in getBoundingBoxes for {img_path}:\n  {e}")
        return np.zeros((0, 4), dtype=np.int32)

    # boxes: (N, 4) with x, y, w, h
    boxes = np.array(boxes, dtype=np.int32)
    if max_proposals is not None:
        boxes = boxes[:max_proposals]

    result = []
    for (x, y, w, h) in boxes:
        x1 = max(0, min(x,     W - 1))
        y1 = max(0, min(y,     H - 1))
        x2 = max(0, min(x + w, W))
        y2 = max(0, min(y + h, H))

        if x2 <= x1 or y2 <= y1:
            continue

        result.append([x1, y1, x2, y2])

    return np.array(result, dtype=np.int32)


# ---------------------------------------------------------------------
# Process splits
# ---------------------------------------------------------------------
def process_split(split_name, filenames, edge_detector, edge_boxes):
    print(f"\nProcessing split '{split_name}' with {len(filenames)} images")
    proposals = {}

    for fname in tqdm(filenames, desc=f"{split_name}"):
        img_path = os.path.join(IMAGES_DIR, fname)

        if not os.path.isfile(img_path):
            print(f"WARNING: File not found: {img_path}")
            continue

        boxes = extract_edgeboxes_for_image(
            img_path,
            edge_detector=edge_detector,
            edge_boxes=edge_boxes,
            max_proposals=MAX_PROPOSALS,
        )
        proposals[fname] = boxes.tolist()

    out_path = os.path.join(OUTPUT_DIR, f"proposals_edgeboxes_{split_name}.json")
    with open(out_path, "w") as f:
        json.dump(proposals, f)

    print(f"Saved proposals for '{split_name}' to: {out_path}")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------
def main():
    splits = ensure_splits()

    train_files = splits.get("train", [])
    val_files   = splits.get("val", [])
    test_files  = splits.get("test", [])

    # Create shared detector & EdgeBoxes once
    edge_detector = create_edge_detector(EDGE_MODEL_PATH)
    edge_boxes = create_edge_boxes(max_boxes=MAX_PROPOSALS)

    if train_files:
        process_split("train", train_files, edge_detector, edge_boxes)

    if val_files:
        process_split("val", val_files, edge_detector, edge_boxes)

    if test_files:
        process_split("test", test_files, edge_detector, edge_boxes)

    print("\nDone.")


if __name__ == "__main__":
    main()
